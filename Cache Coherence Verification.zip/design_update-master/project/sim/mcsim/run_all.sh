irun -f run_4c.f -define TEST1 -define TEST2 -define TEST3 -define TEST4 -define TEST5
