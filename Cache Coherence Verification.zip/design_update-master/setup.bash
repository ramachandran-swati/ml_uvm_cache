#!/bin/bash
echo Setting up UVM environment
export UVMHOME="/softwares/Linux/cadence/INCISIVE152/tools/methodology/UVM/CDNS-1.1d/sv"
source /softwares/setup/cadence/setup.incisive152.bash
source /softwares/setup/cadence/setup.jasper.bash
echo Done
