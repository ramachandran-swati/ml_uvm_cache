# README
***************
## File Organization
• design – folder that contains all cache design files. "cache_top.sv" is the top level file.

• design/common – folder that contains component design files shared by level 1 and level 2 cache.

• design/lv1 – folder that contains component design files which exclusively belongs to level 1 cache.

• design/lv2 – folder that contains component design files which exclusively belongs to level 2 cache.

• sim – folder that contains files to control simulation and store results.
    sim/logs            directory for regression logs
    sim/cov_work        directory for coverage data
 
• gold – folder that contains the arbiter, and memory.

• uvm – folder that contains test bench files: driver, monitor, scoreboard, transactions, packet classes and checkers.

  top level test bench file: "top.sv"
  test bench top level file: "simple_tb.sv"

• test – folder that contains test case files: virtual sequences and test classes.

***************
  ## To run a single test case in GUI  
  run simulation:    irun -f run_dual.f
  select the testcase to be run in run_dual.f (+UVM_TESTNAME=)

  ## To run all test cases:
  cd sim
  ./all.bash

  ## to run regression
  cd sim
  select number of runs in regress.bash with gvim regress.bash
  ./regress.bash
  ./regress.bash n  ##will run exactly n iterations of each test case

  ## to analyze runs
  cd sim/logs
  ./analyze.bash
  observe pass and fail cases

  ## to merge coverage
  imc -execcmd 'merge * -out ALL'
  imc and load sim/cov_work/scope/ALL

  Alternatively run ./gen_cov_html_report.bash from sim to generate a HTML report

***************
## Test Bench Instructions
  1. Test cases are in "test/*.sv". Extend from base_test. Create a virtual sequence extending from base_vseq and define your scenario. Set the virtual sequence as the default sequence for the virtual sequencer

  2. Checkers are provided as assertions or transaction level checks. Assertions are in cpu_lv1_interface.sv or system_bus_interface.sv. Detailed checks are performed in cache_scoreboard.sv 

  3. Currently the design has all 4 cores. 

  4. Level 1 and level 2 cache are all empty at the beginning but memory is pre-filled with initial data. The value of a data block in
  the memory depend on bit[3] of its address. 
  data = addr_bus_lv2_mem[3] ? 32'h5555_aaaa : 32'haaaa_5555; 
  Once you write back to the memory, it will become the value you have written.
  
*******************
